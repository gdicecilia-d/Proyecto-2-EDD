/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package estructuras;

/**
 * Interfaz que deben implementar los elementos que se almacenan en el montículo
 * para poder ser identificados de forma única.
 * 
 * @author Elohym Casais y Grazia Di Cecilia
 */

public interface Identificable {
    
    /**
     * Devuelve el identificador unico el del elemento.
     * @return ID del elemento.
     */
    int getId();
    
}
